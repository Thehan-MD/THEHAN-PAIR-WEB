```NETHU-MD WHATSAPP USER BOT CREATED BY MR NETHMIKA OFC```

<div align="center">
    <b>NETHU-MD USER BOT</b>


<div align="left">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Rubik+Dirt&size=65&pause=1000&color=F72C3F&background=FF20A500&center=true&vCenter=true&width=1000&height=150&lines=NETHU+MD;CREATED+BY+NETHU_MIND;Nethmika" alt="Typing SVG" /></a>   
</p> 

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
   <p align="center">
<a href="https://github.com/Nethmikakaushalyaherath">
    <img src="https://telegra.ph/file/7f0d7a04a30a602307e3d.jpg" width="700px">
  </a>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

`NETHU-MD` whatsapp bot is,

      NETHU-MD යනු ඔබට පහසුවෙන් හැසිරවිය හැකි Bot වරයෙකි.

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">

  <a aria-label="WhatsApp Supported Channel" href="https://whatsapp.com/channel/0029VagCogPGufJ3kZWjsW3A" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Join Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
  <p align="center">
<a href="https://github.com/Nethmikakaushalyaherath/NETHU-MD/fork" target="blank"><img align="center" src="https://i.imgur.com/cxaSEWe.png" alt="Deploy bot" height="112" width="310" /></a>
  <div>
      
<div>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<a href="https://pair-web-public.koyeb.app//"><img src="https://img.shields.io/badge/LOGIN%20WITH-PAIR%20CODE-black" alt="LOGIN WITH PAIR CODE" width="250"></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### DEPLOY HEROKU

 [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Nethmikakaushalyaherath/NETHU-MD)

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### Contact My Main Owner
 <p align="center">

  <a aria-label="Owner WhatsApp Channel" href="https://wa.me/+94704227534?text=Hey_Netha_🤍" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/WhatsApp Owner-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<h2 align="center"> 
</h2>

`Thanks To,me 😅`



***`WARNING` : `DON'T MODIFY THIS BOT FIRST INFORM THE OWNER`***
